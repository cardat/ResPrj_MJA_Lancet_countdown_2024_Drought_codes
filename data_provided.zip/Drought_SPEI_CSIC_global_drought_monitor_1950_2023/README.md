Downloaded on 16/4/2023
updated on 29/8/2024
by Ivan Hanigan

This dataset is called the SPEI Global Drought Monitor and my project is aiming to summarise the most recent years of rainfall (wet and dry) in Australia.

I found the dataset I wanted to use at https://spei.csic.es/map/maps.html. I had
already seen the R package by these authors and used it on Australian weather
data, but this time I wanted to use their precomputed dataset. I chose the
options on the website to download the netCDF file.

In this case I selected the 6-month time scale version as this is recommended by the Lancet Countdown team.  It is worth noting that SPEI values lower than -1.3 are considered to be in drought.

This will need to be added to the metadata. Other important notes are:
- CSIC stands for Consejo Superior de Investigaciones Científicas https://www.csic.es/es
- Licensing
  - The data from SPEI Global Drought Monitor is made available under the Open Database License. Any rights in individual contents of the database are licensed under the Database Contents License.
  - What follows is a human-readable summary of the ODbL 1.0 license. Please, read the full ODbL 1.0 license text for the exact terms that apply.
  - Users of the dataset are free to:

    Share: copy, distribute and use the database, either commercially or non-commercially.
    Create: produce derivative works from the database.
    Adapt: modify, transform and build upon the database.

    Under the following conditions:

    Attribution: You must attribute any public use of the database, or works produced from the database, by citing one or more of the papers referenced in the References section below. For any use or redistribution of the database, or works produced from it, you must make clear to others the license of the original database.
    Share-Alike: If you publicly use any adapted version of this database, or works produced from an adapted database, you must also offer that adapted database under the ODbL.


- Recommended citation:
    Vicente-Serrano SM, Beguería S, López-Moreno JI. A multiscalar drought index sensitive to global warming: The standardized precipitation evapotranspiration index. Journal of Climate. 2010;23(7):1696–1718.


    Santiago Beguería, Borja Latorre, Fergus Reig, Sergio M. Vicente-Serrano
    The Standardised Precipitation Evapotranspiration Index (SPEI) Global Drought Monitor near real-time database of drought conditions at the global scale, with a 1 degree spatial resolution and a monthly time resolution.
    Consejo Superior de Investigaciones Científicas https://www.csic.es/es
    https://spei.csic.es/map/maps.html 
    Accessed 29/08/2024 
    
- NOTES    
    The calibration period for the SPEI is January 1950 to December 2010. The starting date of the dataset is 1955 in order to provide common information across the different SPEI time-scales.
    SPEI time-scales between 1 and 48 months are provided.
